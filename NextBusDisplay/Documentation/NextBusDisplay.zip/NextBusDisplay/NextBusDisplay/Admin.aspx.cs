﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;

namespace NextBusDisplay
{
    public partial class Admin : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);

            var allPlatforms = GetAllPlatformDisplays();

            Table table = new Table();
            table.CssClass = "adminTable";

            TableRow tr = new TableRow();
            table.Rows.Add(tr);

            tr.Cells.Add(new TableCell() { Text = "Route" });
            tr.Cells.Add(new TableCell() { Text = "Stop" });
            tr.Cells.Add(new TableCell() { Text = "Platform" });
            tr.Cells.Add(new TableCell() { Text = "Using NextBus Estimates" });

            foreach (PlatformOverride pd in allPlatforms)
            {
                tr = new TableRow();
                tr.BackColor = System.Drawing.ColorTranslator.FromHtml( GetAlternateRowColor());
                table.Rows.Add(tr);

                tr.Cells.Add(new TableCell() { Text = pd.Route });
                tr.Cells.Add(new TableCell() { Text = pd.Stop });

                DropDownList dl = new DropDownList();
                dl.CssClass = "PlatformOverrideDropdown";
                dl.Items.Add("As Scheduled");
                dl.Items.Add("Platform 1 North");
                dl.Items.Add("Platform 1 South");
                dl.Items.Add("Platform 2 North");
                dl.Items.Add("Platform 2 South");
                dl.Items.Add("Platform 3 North");
                dl.Items.Add("Platform 3 South");
                dl.Items.Add("Platform 4 North");
                dl.Items.Add("Platform 4 South");
                dl.Items.Add("Platform 5 North");
                dl.Items.Add("Platform 5 South");
                dl.Items.Add("Platform 6 North");
                dl.Items.Add("Platform 6 South");
                dl.Items.Add("Platform 7 North");
                dl.Items.Add("Platform 7 South");
                dl.ID = "PlatformOverrideId_" + pd.PlatformOverrideId;
                dl.SelectedIndexChanged += new EventHandler(dl_SelectedIndexChanged);
                dl.AutoPostBack = true;
                dl.SelectedValue = pd.Platform;

                TableCell dlCell = new TableCell();
                dlCell.Controls.Add(dl);
                                              
                tr.Cells.Add(dlCell);

                CheckBox cb = new CheckBox();
                cb.Checked = true;
                cb.ID = "PlatformOverrideCheckBoxId_" + pd.PlatformOverrideId;
                cb.AutoPostBack = true;

                if (pd.UseNextBusFeed.HasValue && pd.UseNextBusFeed.Value == false)
                {
                    cb.Checked = false;
                }

                cb.CheckedChanged += new EventHandler(cb_CheckedChanged);

                TableCell cbCell = new TableCell();
                cbCell.Controls.Add(cb);
                tr.Cells.Add(cbCell);
            }
            
            this.placeHolder1.Controls.Add(table);
            // this.gridView1.DataSource = this.LinqDataSource1;
           
        }

        void cb_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox cb = (CheckBox)sender;

            if (cb.ID.StartsWith("PlatformOverrideCheckBoxId"))
            {
                PlatformOverride po = GetPlatformOverride(int.Parse(cb.ID.Substring(27)));
                po.UseNextBusFeed = cb.Checked;

                dc.SubmitChanges();

            }
        }

        bool altRow = false;
        private string GetAlternateRowColor()
        {
            if (altRow)
            {
                altRow = !altRow;
                return "#005daa";
            }
            else
            {
                altRow = !altRow;
                return "#008c99";
            }

        }

        void dl_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList dl = (DropDownList)sender;

            if (dl.ID.StartsWith("PlatformOverrideId"))
            {
                PlatformOverride po = GetPlatformOverride(int.Parse(dl.ID.Substring(19)));
                po.Platform = dl.SelectedValue;
                
                dc.SubmitChanges();
                
            }
        }

        private List<PlatformOverride> GetAllPlatformDisplays()
        {
            var results = from z in dc.PlatformOverrides
                          orderby z.Route
                          select z;

            return results.ToList();
        }

        DataClasses1DataContext dc = new DataClasses1DataContext();

        private PlatformOverride GetPlatformOverride(int id)
        {
            var results = from z in dc.PlatformOverrides
                          where z.PlatformOverrideId == id
                          select z;

            return results.First();
        }
    }
}