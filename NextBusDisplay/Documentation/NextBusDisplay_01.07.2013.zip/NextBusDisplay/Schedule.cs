﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NextBusDisplay
{
    public class Schedule
    {
        public enum RouteTypes
        {
            Sprinter,
            Coaster,
            Metrolink,
            Amtrak,
            Breeze
        }

        private RouteTypes routeType;
        public RouteTypes RouteType
        {
            get { return routeType; }
            set { routeType = value; }
        }

        string route;

        public string Route
        {
            get { return route; }
            set { route = value; }
        }
        string stop;

        public string Stop
        {
            get { return stop; }
            set { stop = value; }
        }
        string agency;

        string direction;

        public string Direction
        {
            get { return direction; }
            set { direction = value; }
        }

        public string Agency
        {
            get { return agency; }
            set { agency = value; }
        }
        string logo;

        public string Logo
        {
            get { return logo; }
            set { logo = value; }
        }
        string logoMessage;

        public string LogoMessage
        {
            get { return logoMessage; }
            set { logoMessage = value; }
        }
        string logoStyle;

        public string LogoStyle
        {
            get { return logoStyle; }
            set { logoStyle = value; }
        }

        string arrival;

        public string Arrival
        {
            get { return arrival; }
            set { arrival = value; }
        }
        string arrivalMessage;

        public string ArrivalMessage
        {
            get { return arrivalMessage; }
            set { arrivalMessage = value; }
        }
        string departure;

        public string Departure
        {
            get { return departure; }
            set { departure = value; }
        }
        string departureMessage;

        public string DepartureMessage
        {
            get { return departureMessage; }
            set { departureMessage = value; }
        }
    }
}