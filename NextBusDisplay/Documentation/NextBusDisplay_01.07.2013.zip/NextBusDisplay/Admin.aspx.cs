﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;

namespace NextBusDisplay
{
    public partial class Admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);

            var allPlatforms = GetAllPlatformDisplays();

            Table table = new Table();
            table.CssClass = "adminTable";

            TableRow tr = new TableRow();
            table.Rows.Add(tr);

            tr.Cells.Add(new TableCell() { Text = "Route" });
            tr.Cells.Add(new TableCell() { Text = "Stop" });
            tr.Cells.Add(new TableCell() { Text = "Platform" });
            tr.Cells.Add(new TableCell() { Text = "Using NextBus Estimates" });
            string lastRoute = "";
            foreach (PlatformOverride pd in allPlatforms)
            {
                if (lastRoute == "") lastRoute = pd.Route;
                if (lastRoute != pd.Route)
                { // Give It A Blank Separator
                    tr = new TableRow();
                    tr.BackColor = System.Drawing.ColorTranslator.FromHtml("#000000");
                    table.Rows.Add(tr);
                    tr.Cells.Add(new TableCell() { Text = "&nbsp;" });
                    tr.Cells.Add(new TableCell() { Text = "&nbsp;" });
                    tr.Cells.Add(new TableCell() { Text = "&nbsp;" });
                    tr.Cells.Add(new TableCell() { Text = "&nbsp;" });
                }   
                tr = new TableRow();
                tr.BackColor = System.Drawing.ColorTranslator.FromHtml( GetAlternateRowColor());
                table.Rows.Add(tr);

                tr.Cells.Add(new TableCell() { Text = pd.Route });
                string stopDescr = "";
                stopDescr = GetPlatformName(pd.Stop);
                tr.Cells.Add(new TableCell() { Text = pd.Stop + " - " + stopDescr });

                if (pd.Route == "398") 
                {
                    // Route 398 Gets The Dropdown And 399 Doesn't
                    DropDownList dl = new DropDownList();
                    dl.CssClass = "PlatformOverrideDropdown";
                    dl.Items.Add("As Scheduled");
                    dl.Items.Add("Platform 1 - North End");
                    dl.Items.Add("Platform 1 - South End");
                    dl.Items.Add("Platform 2 - North End");
                    dl.Items.Add("Platform 2 - South End");
                    //dl.Items.Add("Platform 3 North");
                    //dl.Items.Add("Platform 3 South");
                    //dl.Items.Add("Platform 4 North");
                    //dl.Items.Add("Platform 4 South");
                    //dl.Items.Add("Platform 5 North");
                    //dl.Items.Add("Platform 5 South");
                    //dl.Items.Add("Platform 6 North");
                    //dl.Items.Add("Platform 6 South");
                    //dl.Items.Add("Platform 7 North");
                    //dl.Items.Add("Platform 7 South");
                    dl.ID = "PlatformOverrideId_" + pd.PlatformOverrideId;
                    dl.SelectedIndexChanged += new EventHandler(dl_SelectedIndexChanged);
                    dl.AutoPostBack = true;
                    TableCell dlCell = new TableCell();
                    dlCell.Controls.Add(dl);
                    tr.Cells.Add(dlCell);
                    dl.SelectedValue = pd.Platform;                         
                    tr.Cells.Add(new TableCell() { Text = "&nbsp;" });
                } 
                else
                {
                    // pd.Route = 399 - Skip The Dropdown & Display The Checkbox
                    tr.Cells.Add(new TableCell() { Text = "&nbsp;" });
                    CheckBox cb = new CheckBox();
                    cb.Checked = true;
                    cb.ID = "PlatformOverrideCheckBoxId_" + pd.PlatformOverrideId;
                    cb.AutoPostBack = true;
                    if (pd.UseNextBusFeed.HasValue && pd.UseNextBusFeed.Value == false)
                    {
                        cb.Checked = false;
                    }

                    cb.CheckedChanged += new EventHandler(cb_CheckedChanged);

                    TableCell cbCell = new TableCell();
                    cbCell.Controls.Add(cb);
                    tr.Cells.Add(cbCell);
                }

            }
            
            this.placeHolder1.Controls.Add(table);
            // this.gridView1.DataSource = this.LinqDataSource1;
           
        }

        void cb_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox cb = (CheckBox)sender;

            if (cb.ID.StartsWith("PlatformOverrideCheckBoxId"))
            {
                PlatformOverride po = GetPlatformOverride(int.Parse(cb.ID.Substring(27)));
                po.UseNextBusFeed = cb.Checked;
                // po.OverrideUntil = System.DateTime.Now + NextStopTimeOnThisPlatform;
                dc.SubmitChanges();

            }
        }

        bool altRow = false;
        private string GetAlternateRowColor()
        {
            if (altRow)
            {
                altRow = !altRow;
                return "#005daa";
            }
            else
            {
                altRow = !altRow;
                return "#008c99";
            }

        }

        void dl_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList dl = (DropDownList)sender;

            if (dl.ID.StartsWith("PlatformOverrideId"))
            {
                PlatformOverride po = GetPlatformOverride(int.Parse(dl.ID.Substring(19)));
                po.Platform = dl.SelectedValue;
                // Update The UpdateUntil Value To Be When The Next Departure Time Is Happening.
                Int32 times = GetNextScheduleTime(GetDaysEnumeration());
                po.OverrideUntil = MinutesToDate(times.ToString());
                dc.SubmitChanges();
                
            }
        }

        private List<PlatformOverride> GetAllPlatformDisplays()
        {
            var results = from z in dc.PlatformOverrides
                          orderby z.Route, z.Stop
                          select z;

            return results.ToList();
        }

        DataClasses1DataContext dc = new DataClasses1DataContext();
        private Int32 GetNextScheduleTime(List<string> DaysList)
        {
            // At Most The List Will Have Three Entries At This Time. The GetDaysEnumeration() Is Modified To Always Return The Same Number Of Items
            string[] aDays = DaysList.ToArray();

            // This assumes that the Coaster trains stop before midnight. Sprinter trains go until shortly after midnight.
            // Fix: Add Minutes after midnight to midnight time in DB so 12:01AM = 1441
            // SELECT t.DepartTime FROM StaticTrains t WHERE t.Train = 'Coaster' AND t.Days IN (@tdays) AND CAST(t.DepartTime AS INT) > fn_MinutesSinceMidnight
            try
            {
                var results = (from t in dc.StaticTrains
                               where (t.Train == "Coaster") 
                                 && (Convert.ToInt32(t.DepartTime) > MinutesSinceMidnight())
                                 && (t.Days == aDays[0] || t.Days == aDays[1] || t.Days == aDays[2])
                               orderby Convert.ToInt32(t.DepartTime)
                               select Convert.ToInt32(t.DepartTime));
                return results.First(); //.ToList(); //.First().ToString();
            }
            catch
            {
                // Midnight Is An Error - This Time Is An Error
                return 0;
            }
        }

        private List<string> GetDaysEnumeration()
        {
            // Check For Holidays (tbl > 0)
            DataClasses1DataContext dc2 = new DataClasses1DataContext();
            var holiday = (from h in dc2.Holidays
                       where h.Holiday == DateTime.Now
                       select h.Holiday).Count();

            List<string> days = new List<string>();
            if (DateTime.Now.DayOfWeek == DayOfWeek.Monday ||
                DateTime.Now.DayOfWeek == DayOfWeek.Tuesday ||
                DateTime.Now.DayOfWeek == DayOfWeek.Wednesday ||
                DateTime.Now.DayOfWeek == DayOfWeek.Thursday
                )
            {
                days.Add("Weekdays");
                days.Add("Mo-Th");
                days.Add("Mo-Th");
            }
            else if (DateTime.Now.DayOfWeek == DayOfWeek.Friday)
            {
                days.Add("Weekdays");
                days.Add("Fri-Sun");
                days.Add("Friday");
            }
            else if (DateTime.Now.DayOfWeek == DayOfWeek.Saturday)
            {
                days.Add("Weekends");
                days.Add("Fri-Sun");
                days.Add("Saturday");
            }
            else if (DateTime.Now.DayOfWeek == DayOfWeek.Sunday || holiday > 0)
            {
                // Holiday Schedule Is "Sunday" Schedule For Sprinter & Coaster
                days.Add("Weekends");
                days.Add("Fri-Sun");
                days.Add("Sunday");

            }
            return days;
        }
        private int MinutesSinceMidnight()
        {
            // Convert The Current Time To Minutes Since Midnight
            // In SQL This Is: DATEDIFF(mi, DATEDIFF(d, 0, GETDATE()), GETDATE())
            DateTime d = DateTime.Now;
            return d.Hour * 60 + d.Minute;
        }

        private DateTime MinutesToDate(string DepartTime)
        {
            // Convert The String DepartTime To The Time Today
            // http://msdn.microsoft.com/en-us/library/bb546099.aspx
            // DepartTime Is A String Integer Of The Minutes Since Midnight
            int iDepart = int.Parse(DepartTime);
            int iHours = iDepart / 60;
            int iMinutes = iDepart % 60;
            DateTime Today = new DateTime(System.DateTime.Today.Year, System.DateTime.Today.Month, System.DateTime.Today.Day, iHours, iMinutes, 0);
            return Today;
        }

        private PlatformOverride GetPlatformOverride(int id)
        {
            // Change This To A Procedure That Updates The Override DateTime?
            var results = from z in dc.PlatformOverrides
                          where z.PlatformOverrideId == id
                          select z;
            return results.First();
        }

        private string GetPlatformName(string StopID)
        {
            // Get The Platform Name In Plain English From The StopDisplay Table
            DataClasses1DataContext dc = new DataClasses1DataContext();
            var results = from s in dc.StopDisplays
                          where s.StopID == StopID
                          select s.Description;
            return results.First();
        }

    }
}