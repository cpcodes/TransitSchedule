﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Xml;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Text;
using System.Web.UI.HtmlControls;


namespace NextBusDisplay
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {
        // const string PlatformAsScheduled = "As Scheduled";
        const string NEXTBUSFEED = "http://webservices.nextbus.com/service/publicXMLFeed?command=predictionsForMultiStops&a=nctd";
        static bool isReset = true;

        [WebMethod]
        public bool CheckReset()
        {
            if (isReset)
            {
                isReset = false;
                return true;
            }
            else
            {
                return false;
            }
        }

        [WebMethod]
        public string GetTime()
        {
            return DateTime.Now.ToShortTimeString();
        }

        [WebMethod]
        public string FetchSchedule(string queryString)
        {
            BuildScheduleFromQueryString(queryString);

            XmlDocument nextBusFeed = FetchNextBusFeed();

            DataClasses1DataContext dc1 = new DataClasses1DataContext();

            int count = 0;
            int minuteNow = (DateTime.Now.Hour * 60) + DateTime.Now.Minute;

            List<string> days = GetDaysEnumeration();

            List<PlatformOverride> platformOverrides = GetAllPlatformDisplays();

            StringBuilder sb = new StringBuilder();

            foreach (Schedule schedule in schedules)
            {
                schedule.Arrival = "";
                schedule.Departure = "";
                schedule.ArrivalMessage = "";
                schedule.DepartureMessage = "";

                string platformDisplay = string.Empty;
                string stopTitle = string.Empty;

                List<PlatformOverride> overrides = GetAllPlatformDisplays();

                var bodyPredictions = nextBusFeed.SelectSingleNode("body/predictions");

                if (bodyPredictions != null)
                {
                    stopTitle = nextBusFeed.SelectSingleNode("body/predictions").Attributes["stopTitle"].Value;
                    stopTitle = stopTitle.Substring(stopTitle.IndexOf(' ') + 1);
                }

                bool useNextBusEstimate = true;

                // overrides will be null when the GetAllPlatformDisplays() fails
                if (overrides != null)
                {
                    foreach (PlatformOverride po in overrides)
                    {
                        if (schedule.Route == po.Route && schedule.Stop.ToString() == po.Stop.ToString())
                        {
                            if (po.UseNextBusFeed.HasValue && po.UseNextBusFeed.Value == false)
                            {
                                useNextBusEstimate = false;
                            }
                            break;
                        }
                    }
                }

                // *****
                // Holiday Hack - Is Today A Holiday?
                // Get The Count Of Today's Date In The Holiday Table (1 or 0) only
                DataClasses1DataContext dc2 = new DataClasses1DataContext();
                var tbl = (from h in dc2.Holidays
                          where h.Holiday == DateTime.Now
                          select h.Holiday).Count();
                if (tbl > 0 && (schedule.Route == "399" || schedule.Route == "398")) // if (DateTime.Now.ToShortDateString() == "12/25/2012")
                {
                    useNextBusEstimate = false; // For Holidays Do Not Use The Estimates From The XML Feed
                    days = new List<string>();
                    days.Add("Weekends");
                    days.Add("Fri-Sun");
                    days.Add("Sunday");
                }
                //********

                if (useNextBusEstimate)
                {
                    XmlNodeList predictions = nextBusFeed.SelectNodes(string.Format("body/predictions[@routeTag='{0}' and @stopTag='{1}']/direction/prediction", schedule.Route, schedule.Stop));
                    if (predictions.Count > 0)
                    {
                        schedule.Departure = this.GetTimeString(int.Parse(predictions[0].Attributes["minutes"].Value));
                        schedule.DepartureMessage = "Estimated Departure Time";
                    }
                }

                if (string.IsNullOrEmpty(schedule.Departure))
                {
                    IOrderedQueryable<StaticTrain> staticTrains = null;

                    if (schedule.RouteType == Schedule.RouteTypes.Coaster ||
                        schedule.RouteType == Schedule.RouteTypes.Metrolink ||
                        schedule.RouteType == Schedule.RouteTypes.Sprinter)
                    {

                        staticTrains = from x in dc1.StaticTrains
                                       where x.Train == schedule.RouteType.ToString() && Convert.ToInt32(x.DepartTime) >= minuteNow &&
                                      days.Contains(x.Days)
                                       orderby Convert.ToInt32(x.DepartTime) ascending
                                       select x;


                    }
                    else if (schedule.RouteType == Schedule.RouteTypes.Amtrak)
                    {
                        staticTrains = from x in dc1.StaticTrains
                                       where x.Train == schedule.RouteType.ToString() && Convert.ToInt32(x.DepartTime) >= minuteNow &&
                                        x.Direction.Contains(schedule.Direction) &&
                                       days.Contains(x.Days)
                                       orderby Convert.ToInt32(x.DepartTime) ascending
                                       select x;
                    }
                    
                    if (staticTrains.Count() == 0)
                    {
                        schedule.Departure = "Tomorrow";

                    }
                    else
                    {
                        var staticTrain = staticTrains.First();
                        schedule.Departure = (DateTime.Parse(DateTime.Now.ToShortDateString()).AddMinutes(Convert.ToInt32(staticTrain.DepartTime))).ToShortTimeString();
                        schedule.DepartureMessage = "Scheduled Departure Time";
                        schedule.Arrival = "No Estimate Available";
                        schedule.ArrivalMessage = "";
                        platformDisplay = staticTrain.Platform;
                    }
                }
                else
                {
                    if (schedule.RouteType == Schedule.RouteTypes.Coaster)
                    {
                        var staticTrains = from x in dc1.StaticTrains
                                           where x.Train == schedule.RouteType.ToString() && Convert.ToInt32(x.DepartTime) >= minuteNow &&
                                          days.Contains(x.Days)
                                           orderby Convert.ToInt32(x.DepartTime) ascending
                                           select x;

                        if (staticTrains.Count() > 0)
                        {
                            platformDisplay = staticTrains.First().Platform;
                        }
                    }
                }

                if (schedule.RouteType == Schedule.RouteTypes.Sprinter)
                {
                    platformDisplay = "Sprinter Platform";
                }


                foreach (PlatformOverride po in overrides)
                {
                    if (schedule.Route == po.Route && schedule.Stop.ToString() == po.Stop.ToString())
                    {
                        if (po.Platform != "As Scheduled")
                        {
                            platformDisplay = po.Platform;
                        }
                    }
                }

                string html =
                   @"<tr style=""background-color:" + GetAlternateRowColor() + @";"">
                        <td style=""padding: .5em 1em 0em 1em;"">
                            <div>
                                <img src=""/Content/Images/" + schedule.Logo + @""" style=""" + schedule.LogoStyle + @""" />
                                <font style=""font-size:2.5em;line-height:1em"">&nbsp;" + schedule.LogoMessage + @"</font>
                            </div>
                            <div style=""font-size:2em"">" + stopTitle + @"</div>
                        </td>
                        <!--<td>
                            <div id=""divDeparture-@alt"" style=""font-size:2.5em"">" + schedule.Arrival + @"</div>
                            <div id=""divDepartureMsg-@alt"" style=""font-size:1.25em;color:Orange;"">" + schedule.ArrivalMessage + @"</div>  
                        </td>-->                  
                        <td>
                            <div id=""divDeparture-@alt"" style=""font-size:2.5em"">" + schedule.Departure + @"</div>
                            <div id=""divDepartureMsg-@alt"" style=""font-size:1.25em;color:Orange;"">" + schedule.DepartureMessage + @"</div>
                        </td>
                        <td style=""font-size:2.5em"">
                            " + platformDisplay + @"
                        </td>
                    </tr>";

                sb.Append(html);
                count++;

                // *****
                // Holiday Hack - Is Today A Holiday?
                if (tbl > 0) // (DateTime.Now.ToShortDateString() == "12/25/2012")
                {
                    days = GetDaysEnumeration();
                }
                //
            }
            string iFrame = "<br><table width='100%' cellspacing='0'><tr><td><iframe src='StatusMessage.htm' width='100%' frameborder='0' scrolling='no'></iframe></td></tr></table>";

            return @"<table width=""100%"" cellspacing=""0"" ><col width=""34%"" /><colgroup span=""2"" width=""33%"" />" + sb.ToString() + "</table>" + iFrame;
        }

        private List<Schedule> schedules;
        private string GetTimeString(int minutes)
        {
            return DateTime.Now.AddMinutes(minutes).ToShortTimeString();
        }

        private void BuildScheduleFromQueryString(string stops)
        {
            stops = stops.Replace("stops=", "");

            schedules = new List<Schedule>();

            foreach (string stop in stops.Split('-'))
            {
                Schedule schedule;
                string route = "";
                string stopId = "";
                if (stop.Contains(','))
                {
                    route = stop.Split(',')[0];
                    stopId = stop.Split(',')[1];

                }
                else
                {
                    route = stop;
                }

                string routeUpper = route.ToUpper();
                if (routeUpper == null)
                {
                    // do nothing
                }
                else if (routeUpper == "399")
                {
                    schedule = new Schedule();
                    schedule.Route = route;
                    schedule.Stop = stopId;
                    schedule.Agency = "nctd";
                    schedule.Logo = "sprinter-logo.png";
                    schedule.LogoMessage = "";
                    schedule.LogoStyle = "width:23em";
                    schedule.RouteType = Schedule.RouteTypes.Sprinter;
                    schedules.Add(schedule);
                }
                else if (routeUpper == "398")
                {
                    schedule = new Schedule();
                    schedule.Route = route;
                    schedule.Stop = stopId;
                    schedule.RouteType = Schedule.RouteTypes.Coaster;
                    schedule.Agency = "nctd";
                    schedule.Logo = "coaster-logo.png";
                    schedule.LogoMessage = "";
                    schedule.LogoStyle = "width:23em";
                    schedules.Add(schedule);
                }
                else if (routeUpper == "METROLINK")
                {
                    schedule = new Schedule();
                    schedule.Route = route;
                    schedule.Stop = stopId;
                    schedule.RouteType = Schedule.RouteTypes.Metrolink;
                    schedule.Agency = "metrolink";
                    schedule.Logo = "metrolink-logo.png";
                    schedule.LogoMessage = "";
                    schedule.LogoStyle = "width:23em";
                    schedules.Add(schedule);
                }
                else if (routeUpper == "AMTRAK")
                {
                    schedule = new Schedule();
                    schedule.Route = route;
                    schedule.Stop = stopId;
                    schedule.RouteType = Schedule.RouteTypes.Amtrak;
                    schedule.Agency = "amtrak";
                    schedule.Logo = "amtrak-logo-nb.png";
                    schedule.LogoMessage = "";
                    schedule.Direction = "North";
                    schedule.LogoStyle = "width:23em";
                    schedules.Add(schedule);

                    schedule = new Schedule();
                    schedule.Route = route;
                    schedule.Stop = stopId;
                    schedule.RouteType = Schedule.RouteTypes.Amtrak;
                    schedule.Agency = "amtrak";
                    schedule.Logo = "amtrak-logo-sb.png";
                    schedule.LogoMessage = "";
                    schedule.Direction = "South";
                    schedule.LogoStyle = "width:23em";
                    schedules.Add(schedule);
                }
                else if (routeUpper == "301")
                {
                    schedule = new Schedule();
                    schedule.Route = route;
                    schedule.Stop = stopId;
                    schedule.RouteType = Schedule.RouteTypes.Breeze;
                    schedule.Agency = "nctd";
                    schedule.Logo = "breeze-logo.png";
                    schedule.LogoMessage = " 101";
                    schedule.LogoStyle = "width:17em";
                    schedules.Add(schedule);
                }
                else
                {
                    schedule = new Schedule();
                    schedule.Route = route;
                    schedule.Stop = stopId;
                    schedule.RouteType = Schedule.RouteTypes.Breeze;
                    schedule.Agency = "nctd";
                    schedule.Logo = "breeze-logo.png";
                    schedule.LogoMessage = " " + schedule.Route;
                    schedule.LogoStyle = "width:17em";
                    schedules.Add(schedule);
                }
            }
        }

        private string BuildNextBusUrl()
        {
            StringBuilder nextBusUrl = new StringBuilder(NEXTBUSFEED);

            foreach (var schedule in schedules)
            {
                nextBusUrl.AppendFormat("&stops={0}|{1}&stops={0}|{2}", schedule.Route, schedule.Stop + "_ar", schedule.Stop);
            }

            return nextBusUrl.ToString();
        }

        private XmlDocument FetchNextBusFeed()
        {
            XmlDocument xmlDoc = new XmlDocument();

            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(BuildNextBusUrl());
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                xmlDoc.Load(response.GetResponseStream());
            }
            catch
            {
            }

            return xmlDoc;
        }

        private List<string> GetDaysEnumeration()
        {
            List<string> days = new List<string>();
            if (DateTime.Now.DayOfWeek == DayOfWeek.Monday ||
                DateTime.Now.DayOfWeek == DayOfWeek.Tuesday ||
                DateTime.Now.DayOfWeek == DayOfWeek.Wednesday ||
                DateTime.Now.DayOfWeek == DayOfWeek.Thursday
                )
            {
                days.Add("Weekdays");
                days.Add("Mo-Th");
            }
            else if (DateTime.Now.DayOfWeek == DayOfWeek.Friday)
            {
                days.Add("Weekdays");
                days.Add("Fri-Sun");
                days.Add("Friday");
            }
            else if (DateTime.Now.DayOfWeek == DayOfWeek.Saturday)
            {
                days.Add("Weekends");
                days.Add("Fri-Sun");
                days.Add("Saturday");
            }
            else if (DateTime.Now.DayOfWeek == DayOfWeek.Sunday)
            {
                days.Add("Weekends");
                days.Add("Fri-Sun");
                days.Add("Sunday");

            }

            return days;
        }

        bool altRow = false;
        private string GetAlternateRowColor()
        {
            if (altRow)
            {
                altRow = !altRow;
                return "#005daa";
            }
            else
            {
                altRow = !altRow;
                return "#008c99";
            }

        }

        private List<PlatformOverride> GetAllPlatformDisplays()
        {
            try
            {
                DataClasses1DataContext dc = new DataClasses1DataContext();
                //var results = from z in dc.PlatformOverrides
                //              orderby z.Route
                //              select z;
                //return results.ToList();
                // sp_PlatformOverride Contains All Of The Linq Above And An Update To Auto-Turn-Off The Platform Override
                var results = dc.sp_PlatformOverride();
                return results.ToList();
            }
            catch
            {
                // Return A Single Standard Override (398, 28000, As Scheduled)
                // List<string> result = new List<string>("Route=398, Stop=28000, Platform=As Scheduled");
                // this will happen when the SQL is down

                // return null;
                // Recurse This Function Until It Returns A Value
                return GetAllPlatformDisplays();
            }
        }

    }
}
