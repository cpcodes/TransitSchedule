USE [NextBusDisplay]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[PlatformOverride](
    [PlatformOverrideId] [INT] IDENTITY(1,1) NOT NULL,
    [Route]              [VARCHAR](50) NOT NULL,
    [Stop]               [VARCHAR](50) NOT NULL,
    [Platform]           [VARCHAR](50) NOT NULL,
    [UseNextBusFeed]     [BIT] NULL,
    [OverrideUntil]      [SMALLDATETIME] NOT NULL,
 CONSTRAINT [PK_PlatformOverride] PRIMARY KEY CLUSTERED
(
    [PlatformOverrideId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
ALTER TABLE [dbo].[PlatformOverride] ADD  CONSTRAINT [DF_PlatformOverride_OverrideUntil]  DEFAULT (GETDATE()) FOR [OverrideUntil]
GO
