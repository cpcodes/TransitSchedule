-- nctdgaov77.NextBusDisplay.dbo.StaticTrains
-- tnctdgaov11.NextBusDisplay.dbo.StaticTrains
/*
http://localhost:2448/Default.aspx?stops=399,27000-398,28000-Metrolink-Amtrak
http://localhost:2448/Admin.aspx?stops=399,27000-398,28000-Metrolink-Amtrak
*/
USE NextBusDisplay
GO
SELECT * FROM (
    --SELECT TOP 1 t.Train, /*t.Days, t.Direction, t.Number, t.Platform,*/ t.DepartTime,
    --      CAST(DATEDIFF(mi, DATEDIFF(d, 0, GETDATE()), GETDATE()) AS INT) AS [CurTime],
    --      CAST(GETDATE() AS TIME) AS SysTime
    --FROM StaticTrains t
    --WHERE t.Train IN ('Sprinter')
    --  AND t.Days IN ('Mon-Thu', 'WeekDays')
    --  AND CAST(t.DepartTime AS INT) > CAST(DATEDIFF(mi, DATEDIFF(d, 0, GETDATE()), GETDATE()) AS INT)
    --UNION
    SELECT t.Train, /*t.Days, t.Direction, t.Number, t.Platform,*/ t.DepartTime,
            CAST(DATEADD(mi, CAST(t.DepartTime AS INT), DATEDIFF(d, 0, GETDATE())) AS TIME) AS [DepTime],
            CAST(DATEDIFF(mi, DATEDIFF(d, 0, GETDATE()), GETDATE()) AS INT) AS [CurTime],
            CAST(GETDATE() AS TIME) AS SysTime
    FROM StaticTrains t
    WHERE t.Train IN ('Coaster')
      AND t.Days IN ('Mon-Thu', 'WeekDays')
      AND CAST(t.DepartTime AS INT) > CAST(DATEDIFF(mi, DATEDIFF(d, 0, GETDATE()), GETDATE()) AS INT)
) t1
ORDER BY CAST(t1.DepartTime AS INT), Train

